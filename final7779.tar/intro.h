/*
name: Mikus Lorence
ONE Card number: 1227388
Unix id: lorencs
lecture section: B1
instructor's name: Martin M�ller
lab section: H01
TA's name: Kiana
*/

#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include "memwatch.h"

//intro main function
int introMain();

// Non-C99 compliant function prototypes (copied from the parse.h file)
FILE *popen(const char *command, const char *type);
int pclose(FILE *stream);
